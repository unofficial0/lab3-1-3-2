﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace participantlibrary
{
    
        [Serializable]
        public class invaliddataexception : Exception
        {
            public invaliddataexception() { }
            public invaliddataexception(string message) : base(message) { }
            public invaliddataexception(string message, Exception inner) : base(message, inner) { }
            protected invaliddataexception(
              System.Runtime.Serialization.SerializationInfo info,
              System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
        }

    
}
