﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace participantlibrary
{
    public class Participants


    {
        invaliddataexception e = new invaliddataexception("Exception : You entered less than 0 and more than 100 value");
        private double foundationMarks, webBasicMarks, dotNetMarks;
        public int EmpId { get; set; }
        public string Name { get; set; }
        public static string CompanyName { get; set; }
        public double FoundationMarks
        {
            get { return foundationMarks; }
            set
            {
                if (value < 0 || value > 100)
                {
                    throw e;
                    //foundationMarks = 0;
                }
                else
                {
                    foundationMarks = value;
                }
            }
        }
        public double WebBasicMarks
        {
            get { return webBasicMarks; }
            set
            {
                if (value < 0 || value > 100)
                {
                    throw e;
                    //webBasicMarks = 0;
                }
                else
                {
                    webBasicMarks = value;
                }
            }
        }
        public double DotNetMarks
        {
            get { return dotNetMarks; }
            set
            {
                if (value < 0 || value > 100)
                {
                    throw e;
                    //dotNetMarks = 0;
                }
                else
                {
                    dotNetMarks = value;
                }
            }
        }
        public double TotalMarks { get; } = 300;
        public double ObtainedMarks
        {
            get
            {
                return FoundationMarks + WebBasicMarks + dotNetMarks;
            }
        }
        public double Percentage
        {
            get
            {
                return (ObtainedMarks / TotalMarks) * 100;
            }
        }
    }
}
