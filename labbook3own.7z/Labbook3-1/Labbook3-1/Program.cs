﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using participantlibrary;


namespace Labbook3_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //ExceptionException e = new ExceptionException("Exception : You entered less than 0 and more than 100 value");
           Participants p = new Participants();

            Console.WriteLine("Properties usage and demo");
            Console.WriteLine("Enter Emp ID");
            p.EmpId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Emp Name");
            p.Name = Console.ReadLine();
            Console.WriteLine("Enter the participants foundation marks");
            double.TryParse(Console.ReadLine(), out double foundationMarks);
            p.FoundationMarks = foundationMarks;
            Console.WriteLine("Enter the participants web based marks");
            double.TryParse(Console.ReadLine(), out double webbasedMarks);
            p.WebBasicMarks = webbasedMarks;
            Console.WriteLine("Enter the participants dot net marks");
            double.TryParse(Console.ReadLine(), out double dotnetMarks);
            p.DotNetMarks = dotnetMarks;
            Console.WriteLine($"Employee {p.Name} with Employee ID {p.EmpId} has a total score of {p.ObtainedMarks} with a percentage of {p.Percentage}");
            Console.Read();
        }
    }
}
